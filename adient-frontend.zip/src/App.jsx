export default function App() {
  return <h1>Adient Sevkiyat Uygulaması</h1>;
}